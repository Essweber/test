<?php
const SECRET = '0hLa83lleBroue11e!';