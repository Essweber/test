# JWT-en-PHP
Génération et vérification de JSON Web Token en PHP

https://www.youtube.com/watch?v=dZgHUq-uEGY